package com.permish.services;

import com.permish.entity.Inventory;
import com.permish.entity.Store;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Stateless
@Remote(InventoryService.class)
public abstract class InventoryServiceImpl implements InventoryService {

    @PersistenceContext
    private EntityManager em;


    @Override
    public void clearList() {
        Query deleteFromPlayer = em.createNamedQuery("Inventory.clearAll");
        deleteFromPlayer.executeUpdate();
    }

    @Override
    public List<Inventory> getInventoryList() {
        List<Inventory> inventoryList = em.createNamedQuery("Inventory.findAll", Inventory.class)
                .getResultList();
        return getInventoryList();
    }

    public List<Inventory> getAllByBuilder() {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Inventory> query = builder.createQuery(Inventory.class);
        Root<Inventory> from  = query.from(Inventory.class);
        TypedQuery<Inventory> q = em.createQuery(query.select(from));
        return q.getResultList();
    }

    @Override
    public void addToList(Inventory inventory) {
        em.persist(inventory);
    }

    @Override
    public void removeFromList(Inventory inventory) {
        Inventory correspondingInventory = em.createNamedQuery("Inventory.getName", Inventory.class)
                .setParameter("name", inventory.getName())
                .getSingleResult();
        em.remove(correspondingInventory);
    }

    @Override
    public void addPlayerRequest(String name, Store store) {
        Inventory correspondingInventory = em.createNamedQuery("Player.getName", Inventory.class)
                .setParameter("name", name)
                .getSingleResult();
        store.setInventory(correspondingInventory);
        em.persist(store);
    }

    @Override
    public List<Store> getAllRequests() {
        return em.createNamedQuery("Request.findAll", Store.class).getResultList();
    }


}
