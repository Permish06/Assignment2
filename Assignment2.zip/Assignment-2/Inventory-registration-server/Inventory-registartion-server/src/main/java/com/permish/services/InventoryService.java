package com.permish.services;

import com.permish.entity.Inventory;
import com.permish.entity.Store;

import java.util.List;

public interface InventoryService {
    void clearList();

    List<Inventory> getInventoryList();

    void addToList(Inventory inventory);
    void removeFromList(Inventory inventory);
    void addPlayerRequest(String userName, Store store);
    List<Store> getAllRequests();
}
