package com.permish.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Store")
@NamedQuery(name = "Store.findAll", query = "SELECT s FROM Store s")
public class Store implements Serializable {
    @Id
    @GeneratedValue
    private Long id;

    @Lob
    @Column(length = 500)
    private String name;

    @Column(name = "location",length = 150)
    private String location;

    @ManyToOne
    @JoinColumn(name = "id_player")
    private Inventory inventory;

    public Store(String name) {
        this.name = name;
    }
}
