package com.permish;

import com.permish.services.StoreService;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.mail.Store;
import javax.naming.NamingException;
import java.util.ArrayList;
import java.util.List;

@SessionScoped
@Named
public class StoreBean {
    private List<com.permish.entity.Store> stores = new ArrayList<>();

    //inject service class
    @EJB
    private StoreService storeService;
    private Object store;

    public void setStore(Store store) {
        this.store = store;
    }

    public List<com.permish.entity.Store> getStores() throws NamingException {

        stores = storeService.getStoreList();

        return stores;
    }


    //add store
    public void addStore(ActionEvent event) throws NamingException {
        //storeService.addToStore(store);
        //store = new store();
    }
}
