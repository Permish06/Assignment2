package com.sidora.service;

import com.sidora.entity.Player;
import com.sidora.entity.Request;

import java.util.List;

public interface PlayerService {
    void clearList();

    List<Player> getPlayerList();

    List<Player> getWaitList();

    void addToList(Player player);
    void removeFromList(Player player);
    Player getById(Long id);
    void addPlayerRequest(String userName, Request request);
    List<Request> getAllRequests();
}
