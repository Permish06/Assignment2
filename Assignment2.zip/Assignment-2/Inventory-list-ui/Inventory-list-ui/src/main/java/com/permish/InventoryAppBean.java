package com.permish;

import com.permish.entity.Inventory;
import com.permish.services.InventoryService;
import org.primefaces.PrimeFaces;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@SessionScoped
@Named
public class InventoryAppBean implements Serializable {


    @NotEmpty
    private int quantity;
    @Size(min = 50)
    private String requestText;
    @Size(min = 5, max = 20)
    @NotEmpty
    private String name;

    @Size(min = 3, max = 20)
    private String sport;
    @NotEmpty
    private double price;
    private boolean isAdmin = false;


    @EJB
    private InventoryService inventoryService;

    public void viewRequests() {
        Map<String, Object> options = new HashMap<>();
        options.put("resizable", false);
        PrimeFaces.current().dialog().openDynamic("requests", options, null);
    }


    public List<Inventory> getInventoryList() {
        return inventoryService.getInventoryList();
    }


    //@Logged
   /* public String addInventory() {

        Inventory inventory = new Inventory(name, sport, quantity, price);
        Optional<Inventory> inventoryOptional = InventoryService.getInventoryList().stream().filter(p ->
                p.getName().equals(name).findFirst();
        if (inventoryOptional.isPresent()) {
            InventoryService.removeFromList(inventory);
        } else {
            InventoryService.addToList(inventory);
        }
        clearFields();
        return "InventoryList";
    }*/

    private void clearFields() {
        setAdmin(false);
        setName("");
        setSport("");
        setQuantity(0);
        setPrice(0.0);
        setRequestText("");
    }


    public String getRequestText() {
        return requestText;
    }

    public void setRequestText(String requestText) {
        this.requestText = requestText;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
